function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let ship;
let asteroids = [];
let score = 0;

function setup() {
  createCanvas(600, 400);
  ship = new Ship();
  for (let i = 0; i < 5; i++) {
    asteroids.push(new Asteroid());
  }
}

function draw() {
  background(0);

  // Atualiza e exibe a nave
  ship.update();
  ship.show();

  // Atualiza e exibe os asteroides
  for (let asteroid of asteroids) {
    asteroid.update();
    asteroid.show();

    // Verifica colisão entre a nave e os asteroides
    if (ship.hits(asteroid)) {
      console.log('Game Over');
      noLoop();
    }
  }

  // Exibe a pontuação
  fill(255);
  textSize(16);
  text('Pontuação: ' + score, 10, 20);
}

function keyPressed() {
  if (keyCode === UP_ARROW) {
    ship.boost();
  }
}

class Ship {
  constructor() {
    this.pos = createVector(width / 2, height / 2);
    this.vel = createVector(0, 0);
    this.heading = 0;
    this.rotation = 0;
    this.isBoosting = false;
  }

  boost() {
    let force = p5.Vector.fromAngle(this.heading);
    force.mult(0.1);
    this.vel.add(force);
  }

  update() {
    this.pos.add(this.vel);
    if (this.isBoosting) {
      this.boost();
    }
  }

  hits(asteroid) {
    let d = dist(this.pos.x, this.pos.y, asteroid.pos.x, asteroid.pos.y);
    if (d < 20) {
      return true;
    } else {
      return false;
    }
  }

  show() {
    push();
    translate(this.pos.x, this.pos.y);
    rotate(this.heading + PI / 2);
    fill(0, 0, 255);
    stroke(255);
    triangle(-10, 20, 10, 20, 0, -20);
    pop();
  }
}

class Asteroid {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D();
    this.radius = random(15, 50);
  }

  update() {
    this.pos.add(this.vel);
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.y < 0) this.pos.y = height;
    if (this.pos.y > height) this.pos.y = 0;
  }

  show() {
    noFill();
    stroke(255);
    ellipse(this.pos.x, this.pos.y, this.radius * 2);
  }
}
