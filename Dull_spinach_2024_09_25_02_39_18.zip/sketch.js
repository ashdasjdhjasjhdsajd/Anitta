function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let balls = [];

function setup() {
  createCanvas(800, 600);
  for (let i = 0; i < 10; i++) {
    balls.push(new Ball(random(width), random(height), random(20, 50)));
  }
}

function draw() {
  background(0);

  for (let ball of balls) {
    ball.update();
    ball.display();
  }
}

class Ball {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.speedX = random(-5, 5);
    this.speedY = random(-5, 5);
    this.color = color(random(255), random(255), random(255));
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;

    if (this.x < 0 || this.x > width) {
      this.speedX *= -1;
      this.color = color(random(255), random(255), random(255));
    }

    if (this.y < 0 || this.y > height) {
      this.speedY *= -1;
      this.color = color(random(255), random(255), random(255));
    }
  }

  display() {
    fill(this.color);
    noStroke();
    ellipse(this.x, this.y, this.size);
  }
}
